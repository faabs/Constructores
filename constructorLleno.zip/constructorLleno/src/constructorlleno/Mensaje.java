package constructorlleno;

/**
 *
 * @author FABIOLA
 * @version 1.0
 */
public class Mensaje {
    //Se crean tres variables privada de tipo String 
    private String remitente;
    private String destinatario;
    public String contenido;
    
    Mensaje(String destinatario, String remitente, String contenido){
        this.destinatario=destinatario;
        this.remitente=remitente;
        this.contenido=contenido;
    }
    
    Mensaje(){
        System.out.println("No se puede enviar un mensaje sin información");
    }
    
    //Método para obtener el contenido del mensaje
    public String getContenido () {
        contenido="Hola";
        return contenido; 
    }
    
 //Método para obtener el remitente
    public String getRemitente () {
        remitente="Fabiola";
        return remitente; 
    } 
    //Método para obtener el destinatario
    public String getDestinatario () {
        destinatario="Luis";
        return destinatario;
    } 
}
