package constructorlleno;

/**
 *
 * @author FABIOLA
 * @version 1.0
 */
public class ConstructorLleno {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Se instancia un objeto con la clase Mensaje
        Mensaje envia=new Mensaje();
    }
    
}
