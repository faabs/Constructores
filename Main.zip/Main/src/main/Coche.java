package main;

/**
 *
 * @author FABIOLA
 * @version 1.0
 */
public class Coche {
    //Se crea una variable privada de tipo doble 
    private double gasolina;
    
    //Se crea un constructor lleno de la clase que recibe la variable gasolina
     Coche(double gasolina){
         this.gasolina=gasolina;
     }
     
     //Se crea un constructor vacio que despliega un mensaje en caso de no haber gasolina 
     Coche (){
         System.out.println("No hay gasolina");
     }
     
     //Método que verifica el nivel de gasolina que tiene el coche
     public void arranca(){
         if (gasolina>0){
             if (gasolina>=30){
                 System.out.println("Arranca");
             }
             else{
                 System.out.println("No hay suficiente gasolina");
             }
         }
         else{
             System.out.println("No tienes gasolina");
         }
     }
     
}
