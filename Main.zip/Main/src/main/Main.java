package main;

/**
 *
 * @author FABIOLA
 * @version 1.0
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Se instancia el objeto con la clase Coche 
        Coche cochecito=new Coche();
    }
    
}
